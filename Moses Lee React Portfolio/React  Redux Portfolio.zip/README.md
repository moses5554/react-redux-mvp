# My example project

Started this project as a way to explore some ideas that I had. Decided to go the artistic route and use Codepen to produce some simple components. Unforunately, I am limited to 50 files so it was slightly frustrating not being able to improve it some more.

### Tools
1. React: Frontend UI Library
2. Redux: State Management
3. Redux-Thunk: Async State Management
4. React Router: Routing Logic
5. Classnames: Class name logic
6. Canvas: Creating some neat effects for the header