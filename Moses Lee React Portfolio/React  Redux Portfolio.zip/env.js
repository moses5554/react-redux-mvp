export default {
	"codepenApiUrl": "https://cpv2api.com",
	"userName": "howlingwolf"
}