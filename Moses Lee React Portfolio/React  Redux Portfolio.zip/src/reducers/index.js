import { combineReducers } from 'redux'
import pens from './pens'

const reducers = combineReducers({
  pens
});

export default reducers; 